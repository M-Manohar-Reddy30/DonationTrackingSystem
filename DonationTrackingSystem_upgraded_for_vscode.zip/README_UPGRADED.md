
# DonationTrackingSystem - Upgraded for VS Code

This archive was generated automatically to make the project easier to open and run in **VS Code**.

Detected project types:
- Maven project: No
- Gradle project: No
- Maven wrapper present: No
- Gradle wrapper present: No

## What I added
- `.vscode/launch.json` and `.vscode/tasks.json` with common run tasks.
- `README_UPGRADED.md` (this file) with run instructions.

## How to run in VS Code

1. Open this folder in VS Code.
2. Install recommended extensions:
   - Java Extension Pack (Red Hat)
   - Spring Boot Extension Pack (optional)
3. If it's a Maven project:
   - Use the terminal task: `./mvnw spring-boot:run` (or `mvn spring-boot:run` if you don't have wrapper)
   - Or use the Run|Debug sidebar to launch the main class.
4. If it's a Gradle project:
   - Use `./gradlew bootRun` (or `gradle bootRun`).
5. If you need to add environment variables, edit `src/main/resources/application.properties` or use VS Code launch args.

## Notes
- I did not modify source code logic. I focused on making the project structure VS Code-friendly.
- If you want me to additionally integrate Voice/Web3/Chatbot features or fix compile errors, reply and I'll perform those changes.

